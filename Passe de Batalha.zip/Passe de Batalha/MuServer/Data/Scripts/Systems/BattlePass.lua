-- Passe de batalha: moedas, itens no NPC de resgate e missoes acumuladas.
BattlePass = {}
local B, C = BattlePass, BattlePassConfig
local MAX = 2147483647
local function integer(v, min, max)
    return type(v) == 'number' and v == math.floor(v) and v >= min and v <= max
end
local function identifier(s)
    assert(type(s) == 'string' and #s <= 128 and s:match('^[A-Za-z_][A-Za-z0-9_]*$'), 'BattlePass: identificador SQL invalido')
    return '[' .. s .. ']'
end
local function quote(s) return "'" .. s:gsub("'", "''") .. "'" end
local function date(s)
    return type(s) == 'string' and s:match('^%d%d%d%d%-%d%d%-%d%dT%d%d:%d%d:%d%d$')
end
-- Numeros da configuracao anterior continuam sendo premios em moeda.
local function rewardData(value)
    if type(value)=='number' then return value,{} end
    assert(type(value)=='table','BattlePass: premio invalido')
    -- Cash e o nome atual; Amount continua aceito por compatibilidade.
    return value.Cash or value.Amount or 0,value.Items or {}
end
local function mission(level)
    return level.Kills or 0, level.OnlineMinutes or 0
end
-- Category opcional separa grupo e numero; sem ela Index continua absoluto.
local function itemIndex(item)
    assert(type(item)=='table','BattlePass: item invalido')
    if item.Category ~= nil then
        assert(integer(item.Category,0,15) and integer(item.Index,0,511),'BattlePass: categoria ou indice do item invalido')
        return item.Category*512+item.Index
    end
    assert(integer(item.Index,0,8191),'BattlePass: indice do item invalido')
    return item.Index
end
-- As trilhas sao identificadas por 0 = Free, 1 = VIP e 2 = Donate.
local rewardKeys = {[0]='FreeReward',[1]='VipReward',[2]='DonateReward'}
local trackNumbers = {free=0,vip=1,don=2}
local function rewardFor(level, number)
    if level.Premios ~= nil then return level.Premios[number] end
    return level[rewardKeys[number]]
end
local trackNames={[0]='FREE [0]',[1]='VIP [1]',[2]='DONATE [2]'}
local function validateReward(value,where)
    where=where or 'premio'
    assert(value~=nil,'BattlePass: '..where..' nao configurado (use Cash e/ou Items)')
    local amount,items=rewardData(value)
    assert(integer(amount,0,MAX),'BattlePass: '..where..' - Cash invalido')
    assert(type(items)=='table' and #items<=10,'BattlePass: '..where..' - Items deve ser uma lista com ate 10 itens')
    assert(amount>0 or #items>0,'BattlePass: '..where..' esta vazio (informe Cash maior que 0 ou ao menos 1 item)')
    for n,item in ipairs(items) do
        local w=where..' - item '..n
        assert(type(item)=='table',"BattlePass: "..w..' invalido')
        -- Full=true = atalho para item completo (+15, skill, luck, opcao +28, excelente total).
        -- Qualquer campo escrito no proprio item tem prioridade sobre o atalho.
        if item.Full then
            for k,v in pairs({Level=15,Skill=1,Luck=1,Option=7,Excellent=63}) do
                if item[k]==nil then item[k]=v end
            end
        end
        if item.Category ~= nil then
            assert(integer(item.Category,0,15) and integer(item.Index,0,511),'BattlePass: '..w..' - Category (0-15) ou Index (0-511) invalido')
        else
            assert(integer(item.Index,0,8191),'BattlePass: '..w..' - Index invalido')
        end
        assert(type(item.Name)=='string' and #item.Name>0 and #item.Name<=24,'BattlePass: '..w..' - Name deve ter de 1 a 24 letras')
        local limits={Level=15,Skill=1,Luck=1,Option=7,Excellent=63,Ancient=255,JoH=255,SockBonus=255}
        for _,field in ipairs({'Level','Skill','Luck','Option','Excellent','Ancient','JoH','SockBonus'}) do
            assert(integer(item[field] or 0,0,limits[field]),'BattlePass: '..w..' - '..field..' invalido (maximo '..limits[field]..')')
        end
        assert(integer(item.Count or 1,1,10),'BattlePass: '..w..' - Count deve ser de 1 a 10')
        assert(integer(item.Time or 0,0,MAX),'BattlePass: '..w..' - Time deve ser segundos (0 = eterno)')
    end
end
local function validate()
    assert(type(C) == 'table', 'BattlePass: carregue BattlePassConfig.lua')
    assert(type(C.Enabled) == 'boolean', 'BattlePass: Enabled invalido')
    assert(type(C.Command) == 'string' and C.Command:match('^/[a-z0-9]+$'), 'BattlePass: comando invalido')
    assert(integer(C.Packet, 1, 255), 'BattlePass: pacote invalido')
    assert(integer(C.Season, 1, MAX), 'BattlePass: temporada invalida')
    assert(integer(C.MinVip, 1, MAX), 'BattlePass: MinVip deve ser maior que zero')
    assert(date(C.StartUTC) and date(C.EndUTC) and C.StartUTC < C.EndUTC, 'BattlePass: datas UTC invalidas')
    assert(type(C.Monsters) == 'table', 'BattlePass: configure Monsters')
    local monsters = 0
    for k,v in pairs(C.Monsters) do
        assert(integer(k, 0, 65535) and v == true, 'BattlePass: classe de monstro invalida')
        monsters = monsters + 1
    end
    assert(monsters > 0, 'BattlePass: configure ao menos um monstro')
    assert(type(C.Currency) == 'table', 'BattlePass: configure Currency')
    identifier(C.Currency.Table); identifier(C.Currency.Column); identifier(C.Currency.Key)
    assert(type(C.Currency.Name) == 'string' and #C.Currency.Name > 0 and #C.Currency.Name <= 30, 'BattlePass: nome da moeda invalido')
    local purchase=C.DonatePurchase
    assert(type(purchase)=='table' and type(purchase.Enabled)=='boolean' and integer(purchase.Price,1,MAX),'BattlePass: compra Donate invalida')
    identifier(purchase.Table); identifier(purchase.Column); identifier(purchase.Key)
    assert(type(purchase.Name)=='string' and #purchase.Name>0 and #purchase.Name<=30,'BattlePass: moeda Donate invalida')
    assert(type(C.Levels) == 'table' and #C.Levels > 0 and #C.Levels <= 100, 'BattlePass: configure de 1 a 100 niveis')
    assert(integer(C.ItemExpireDays or 30,1,3650),'BattlePass: validade de item invalida')
    assert(C.ItemDelivery==nil or C.ItemDelivery=='inventory' or C.ItemDelivery=='npc',"BattlePass: ItemDelivery deve ser 'inventory' ou 'npc'")
    local previous = 0
    for levelNumber,level in ipairs(C.Levels) do
        assert(integer(level.Points,previous+1,MAX),'BattlePass: nivel '..levelNumber..' - Points deve ser maior que o nivel anterior ('..previous..')')
        local kills,minutes=mission(level)
        assert(integer(kills,0,MAX) and integer(minutes,0,math.floor(MAX/60)),'BattlePass: missao invalida')
        if level.Premios ~= nil then
            assert(type(level.Premios)=='table', 'BattlePass: Premios deve ser uma tabela')
            assert(level.FreeReward==nil and level.VipReward==nil and level.DonateReward==nil, 'BattlePass: nao misture Premios e campos antigos no mesmo nivel')
            for number in pairs(level.Premios) do
                assert(integer(number,0,2),'BattlePass: trilha deve ser 0, 1 ou 2')
            end
        end
        for number=0,2 do validateReward(rewardFor(level,number),'nivel '..levelNumber..' trilha '..trackNames[number]) end
        previous = level.Points
    end
end
local lastError = 0
local function logError()
    if os.time() - lastError >= 60 then
        LogAddC(2, '[BattlePass] Falha SQL. Confira BattlePass.sql, configuracao e conexao.')
        lastError = os.time()
    end
end
local function query(sql, columns)
    local d = DataBase.getDb()
    if not d then logError(); return nil end
    local ok, result = pcall(function()
        if d:exec(sql) == 0 then return nil end
        if d:fetch() == SQL_NO_DATA then return nil end
        local row = {}
        for _,key in ipairs(columns) do row[key] = d:getInt(key) end
        return row
    end)
    pcall(function() d:clear() end)
    if not ok or not result then
        logError()
        return nil
    end
    return result
end
local function active()
    return "GETUTCDATE() >= CONVERT(datetime2(0)," .. quote(C.StartUTC) .. ",126) AND GETUTCDATE() < CONVERT(datetime2(0)," .. quote(C.EndUTC) .. ",126)"
end
local function account(player)
    if player:getConnected() < 3 then return nil end
    local id = player:getAccountID()
    if type(id) ~= 'string' or #id == 0 or #id > 64 then return nil end
    return id
end
local function key(id)
    return 'Season=' .. C.Season .. ' AND AccountID=' .. quote(id)
end
local function transact(body)
    return 'SET NOCOUNT ON; SET XACT_ABORT ON; BEGIN TRY BEGIN TRANSACTION; ' .. body ..
        " COMMIT; SELECT @result AS Result; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; SELECT -1 AS Result; END CATCH;"
end
function B.MonsterDie(index, monsterIndex)
    if not C.Enabled then return end
    if not integer(index, OBJECT_START_USER, MAX_OBJECT) or not integer(monsterIndex, OBJECT_START_MONSTER, MAX_OBJECT_MONSTER) then return end
    local player = User.new(index)
    local id = account(player)
    if not id or not C.Monsters[User.new(monsterIndex):getClass()] then return end
    local k = key(id)
    local cap = C.Levels[#C.Levels].Points
    -- A chave primaria e os locks de intervalo serializam a criacao e os incrementos.
    local sql = 'DECLARE @result int=0; IF ' .. active() .. ' BEGIN ' ..
        'IF NOT EXISTS (SELECT 1 FROM dbo.BattlePassProgress WITH (UPDLOCK,HOLDLOCK) WHERE ' .. k .. ') ' ..
        'INSERT dbo.BattlePassProgress(Season,AccountID,Points) VALUES(' .. C.Season .. ',' .. quote(id) .. ',0); ' ..
        'UPDATE dbo.BattlePassProgress SET Points=CASE WHEN Points<' .. cap .. ' THEN Points+1 ELSE Points END,Kills=CASE WHEN Kills<' .. MAX .. ' THEN Kills+1 ELSE Kills END WHERE ' .. k .. '; SET @result=1; END;'
    local row = query(transact(sql), {'Result'})
    if row and row.Result == -1 then logError() end
end
local function say(index, message) SendMessage('[Passe] ' .. message, index, 1) end
local function eligibleVip(player)
    local vip = player:getVip()
    return integer(vip, 0, MAX) and vip >= C.MinVip
end
local function status(index, id, player)
    local k = key(id)
    local row = query('SET NOCOUNT ON; SELECT CASE WHEN ' .. active() .. ' THEN 1 ELSE 0 END AS Active, ' ..
        'COALESCE((SELECT Points FROM dbo.BattlePassProgress WHERE ' .. k .. '),0) AS Points, ' ..
        'COALESCE((SELECT Donate FROM dbo.BattlePassProgress WHERE ' .. k .. '),0) AS Donate;', {'Active','Points','Donate'})
    if not row then return say(index, 'Banco indisponivel. Tente novamente.') end
    if row.Active ~= 1 then return say(index, 'Temporada fora do periodo ativo (UTC).') end
    local level = 0
    for i,v in ipairs(C.Levels) do if row.Points >= v.Points then level = i end end
    say(index, string.format('Temporada %d: %d pontos, nivel %d/%d.', C.Season, row.Points, level, #C.Levels))
    if level < #C.Levels then say(index, string.format('Proximo nivel: %d pontos.', C.Levels[level + 1].Points)) end
    say(index, 'VIP: ' .. (eligibleVip(player) and 'ativo' or 'inativo') .. ' | Donate: ' .. (row.Donate == 1 and 'ativo' or 'inativo'))
    say(index, 'Use ' .. C.Command .. ' premio free/vip/donate <nivel>.')
end
local function busy(p)
    return p:getInterfaceUse()~=0 or p:getInterfaceType()~=0 or p:getState()==32 or p:getDieRegen()~=0 or p:getTeleport()~=0
end
-- 1 unidade de item para a tabela do NPC de resgate (modo 'npc' e sobra do modo 'inventory').
local function rescueInsert(id,item)
    local values={quote(id),itemIndex(item),item.Level or 0,item.Skill or 0,item.Luck or 0,item.Option or 0,item.Excellent or 0,item.Ancient or 0,item.JoH or 0,item.SockBonus or 0,255,255,255,255,255,0,0}
    return 'INSERT dbo.NPC_RESCUE_ITENS ([Account],[ItemIndex],[Level],[Option1],[Option2],[Option3],[Exc],[Ancient],[JoH],[SockBonus],[Sock1],[Sock2],[Sock3],[Sock4],[Sock5],[Delivered],[ItemTimeExpire],[TimeExpire]) VALUES (' .. table.concat(values,',') .. ',DATEADD(day,' .. (C.ItemExpireDays or 30) .. ',GETDATE())); '
end
local function none(v) return (v or 0)==0 and 255 or v end -- 255 = "sem" para Ancient/JoH/Socket
-- Entrega direta na mochila. Se faltar espaco ou der erro, a unidade vai ao NPC de resgate (nunca se perde).
local function deliver(player,id,items)
    local index,given,overflow=player:getIndex(),0,0
    for _,item in ipairs(items) do
        for _=1,item.Count or 1 do
            local ok=InventoryCheckSpaceByItem(index,itemIndex(item))==1 and pcall(CreateItemInventory,index,itemIndex(item),
                item.Level or 0,item.Skill or 0,item.Luck or 0,item.Option or 0,item.Excellent or 0,
                none(item.Ancient),item.JoH or 0,none(item.SockBonus),255,255,255,255,255,item.Time or 0)
            if ok then given=given+1
            else
                overflow=overflow+1
                local r=query(transact('DECLARE @result int=0; '..rescueInsert(id,item)..' SET @result=1;'),{'Result'})
                if not (r and r.Result==1) then LogAddC(2,'[BattlePass] ITEM NAO ENTREGUE: conta '..id..' item '..item.Name..' (indice '..itemIndex(item)..'). Entregue manualmente.') end
            end
        end
    end
    local note=' Itens entregues na mochila!'
    if overflow>0 then note=string.format(' %d item(ns) na mochila; %d foram para o NPC de resgate (mochila cheia).',given,overflow) end
    return note
end
local function claim(index, id, track, level, player)
    local tier = C.Levels[level]
    if not tier then return 'Nivel invalido.' end
    if track == 'vip' and not eligibleVip(player) then
        return 'VIP do jogo inativo ou abaixo do nivel exigido.'
    end
    local k = key(id)
    local reward,items = rewardData(rewardFor(tier,trackNumbers[track]))
    local kills,minutes=mission(tier)
    local cur = C.Currency
    local tableName, column, owner = '[dbo].' .. identifier(cur.Table), identifier(cur.Column), identifier(cur.Key)
    local direct=(C.ItemDelivery or 'inventory')=='inventory' and #items>0
    if direct then
        if busy(player) then return 'Feche troca, bau e loja antes de resgatar.' end
        for _,item in ipairs(items) do
            if InventoryCheckSpaceByItem(index,itemIndex(item))~=1 then return 'Mochila cheia. Libere espaco e tente novamente.' end
        end
    end
    local itemSQL={}
    if not direct then
        for _,item in ipairs(items) do
            for _=1,item.Count or 1 do itemSQL[#itemSQL+1]=rescueInsert(id,item) end
        end
    end
    local credit=''
    if reward>0 then
        credit='SELECT @matches=COUNT_BIG(*),@balance=MIN(CASE WHEN ' .. column .. ' BETWEEN 0 AND ' .. MAX .. ' AND ' .. column .. '=FLOOR(' .. column .. ') THEN CONVERT(bigint,' .. column .. ') ELSE -1 END) FROM ' .. tableName .. ' WITH (UPDLOCK,HOLDLOCK) WHERE ' .. owner .. '=' .. quote(id) .. '; ' ..
            'IF @matches<>1 OR @balance IS NULL OR @balance<0 OR @balance+' .. reward .. '>' .. MAX .. " RAISERROR('BattlePass: saldo indisponivel',16,1); " ..
            'UPDATE ' .. tableName .. ' SET ' .. column .. '=' .. column .. '+' .. reward .. ' WHERE ' .. owner .. '=' .. quote(id) .. "; IF @@ROWCOUNT<>1 RAISERROR('BattlePass: moeda invalida',16,1); "
    end
    local sql = 'DECLARE @result int=0,@points int,@kills int,@online int,@donate bit,@matches bigint,@balance bigint; IF ' .. active() .. ' BEGIN ' ..
        'SELECT @points=Points,@kills=Kills,@online=OnlineSeconds,@donate=Donate FROM dbo.BattlePassProgress WITH (UPDLOCK,HOLDLOCK) WHERE ' .. k .. '; ' ..
        'IF @points IS NULL OR @points<' .. tier.Points .. ' SET @result=2; ' ..
        'ELSE IF @kills<' .. kills .. ' OR @online<' .. minutes*60 .. ' SET @result=6; ' ..
        (track == 'don' and 'ELSE IF @donate<>1 SET @result=5; ' or '') ..
        'ELSE IF EXISTS(SELECT 1 FROM dbo.BattlePassClaim WITH (UPDLOCK,HOLDLOCK) WHERE ' .. k .. ' AND Track=' .. quote(track) .. ' AND Level=' .. level .. ') SET @result=3; ' ..
        (#items>0 and not direct and "ELSE IF LEN(" .. quote(id) .. ")>10 OR OBJECT_ID('dbo.NPC_RESCUE_ITENS','U') IS NULL SET @result=7; " or '') ..
        'ELSE BEGIN ' .. credit .. table.concat(itemSQL) ..
        'INSERT dbo.BattlePassClaim(Season,AccountID,Track,Level,PointsRequired,Reward,CurrencyTable,CurrencyColumn) VALUES(' .. C.Season .. ',' .. quote(id) .. ',' .. quote(track) .. ',' .. level .. ',' .. tier.Points .. ',' .. reward .. ',' .. quote(cur.Table) .. ',' .. quote(cur.Column) .. '); SET @result=1; END; END;'
    local row = query(transact(sql), {'Result'})
    if not row or row.Result == -1 then
        if row then logError() end
        return 'Falha no banco; tente novamente ou contate o administrador.'
    end
    local itemNote = #items>0 and ' Itens enviados ao NPC de resgate.' or ''
    if row.Result == 1 and direct then itemNote = deliver(player,id,items) end
    local messages = {
        [0] = 'Temporada fora do periodo ativo (UTC).',
        [1] = string.format('Nivel %d:%s%s', level, reward>0 and (' '..reward..' '..cur.Name..' creditados.') or '', itemNote),
        [2] = string.format('Nivel %d exige %d pontos; premio: %d %s.', level, tier.Points, reward, cur.Name),
        [3] = 'Premio deste nivel ja resgatado.',
        [4] = 'Saldo indisponivel; contate o administrador.',
        [5] = 'Trilha Donate inativa. Contate o administrador.',
        [6] = 'Complete as missoes deste nivel. Veja MISSOES na janela.',
        [7] = 'NPC de resgate indisponivel ou conta incompativel.',
    }
    return messages[row.Result] or 'Resposta inesperada do banco.'
end
local function buyDonate(id)
    local p=C.DonatePurchase
    if not p.Enabled then return 'Compra Donate desativada.' end
    local k=key(id)
    local tbl,col,owner='[dbo].'..identifier(p.Table),identifier(p.Column),identifier(p.Key)
    local sql='DECLARE @result int=0,@donate bit,@matches bigint,@balance bigint; IF '..active()..' BEGIN IF NOT EXISTS(SELECT 1 FROM dbo.BattlePassProgress WITH (UPDLOCK,HOLDLOCK) WHERE '..k..') INSERT dbo.BattlePassProgress(Season,AccountID,Points) VALUES('..C.Season..','..quote(id)..',0); SELECT @donate=Donate FROM dbo.BattlePassProgress WITH (UPDLOCK,HOLDLOCK) WHERE '..k..'; IF @donate=1 SET @result=2; ELSE BEGIN SELECT @matches=COUNT_BIG(*),@balance=MIN(CASE WHEN '..col..' BETWEEN 0 AND '..MAX..' AND '..col..'=FLOOR('..col..') THEN CONVERT(bigint,'..col..') ELSE -1 END) FROM '..tbl..' WITH (UPDLOCK,HOLDLOCK) WHERE '..owner..'='..quote(id)..'; IF @matches<>1 OR @balance IS NULL OR @balance<0 SET @result=4; ELSE IF @balance<'..p.Price..' SET @result=3; ELSE BEGIN UPDATE '..tbl..' SET '..col..'='..col..'-'..p.Price..' WHERE '..owner..'='..quote(id)..'; IF @@ROWCOUNT<>1 RAISERROR(\'BattlePass: moeda invalida\',16,1); UPDATE dbo.BattlePassProgress SET Donate=1 WHERE '..k..'; SET @result=1; END; END; END;'
    local row=query(transact(sql),{'Result'})
    local messages={[0]='Temporada fora do periodo ativo.',[1]='Donate comprado! Trilha liberada nesta temporada.',[2]='Donate ja esta ativo. Nenhuma cobranca.',[3]='Saldo insuficiente para comprar o Donate.',[4]='Saldo indisponivel. Confira a moeda configurada.'}
    return row and messages[row.Result] or 'Falha no banco. Atualize antes de tentar novamente.'
end
local sendPacket
function B.Command(index, text)
    if not C.Enabled then return say(index, 'Sistema desativado.') end
    local player = User.new(index)
    local id = account(player)
    if not id then return end
    local rest = text:match('^%S+%s*(.-)%s*$') or ''
    if rest == '' then
        sendPacket(player, 0, 4, function() end)
        return status(index, id, player)
    end
    local track, level = rest:match('^premio%s+(%a+)%s+(%d+)$')
    if (track == 'free' or track == 'vip' or track == 'donate') and #level <= 3 then return say(index, claim(index, id, track == 'donate' and 'don' or track, tonumber(level), player)) end
    say(index, 'Use ' .. C.Command .. ' ou ' .. C.Command .. ' premio free/vip/donate <nivel>.')
end

-- O cliente recebe somente uma fotografia do estado; o resgate e validado novamente no SQL.
local function snapshot(id)
    local values = {}
    for i=1,#C.Levels do values[#values+1] = '(' .. i .. ')' end
    local sql = 'SELECT v.Level,COALESCE(p.Points,0) AS Points,CASE WHEN ' .. active() ..
        ' THEN 1 ELSE 0 END AS Active,COALESCE(p.Kills,0) AS Kills,COALESCE(p.OnlineSeconds,0) AS OnlineSeconds,COALESCE(p.Donate,0) AS Donate,CASE WHEN f.Level IS NULL THEN 0 ELSE 1 END AS FreeClaimed,' ..
        'CASE WHEN t.Level IS NULL THEN 0 ELSE 1 END AS VipClaimed,CASE WHEN z.Level IS NULL THEN 0 ELSE 1 END AS DonateClaimed FROM (VALUES ' .. table.concat(values,',') ..
        ') v(Level) LEFT JOIN dbo.BattlePassProgress p ON p.Season=' .. C.Season .. ' AND p.AccountID=' .. quote(id) ..
        ' LEFT JOIN dbo.BattlePassClaim f ON f.Season=' .. C.Season .. ' AND f.AccountID=' .. quote(id) ..
        " AND f.Track='free' AND f.Level=v.Level LEFT JOIN dbo.BattlePassClaim t ON t.Season=" .. C.Season ..
        ' AND t.AccountID=' .. quote(id) .. " AND t.Track='vip' AND t.Level=v.Level LEFT JOIN dbo.BattlePassClaim z ON z.Season=" .. C.Season ..
        ' AND z.AccountID=' .. quote(id) .. " AND z.Track='don' AND z.Level=v.Level ORDER BY v.Level;"
    local d = DataBase.getDb()
    if not d then logError(); return nil end
    local ok, rows = pcall(function()
        if d:exec(sql) == 0 then return nil end
        local result, count = {}, 0
        while d:fetch() ~= SQL_NO_DATA do
            count = count + 1
            if count > #C.Levels then return nil end
            local n = d:getInt('Level')
            if not integer(n,1,#C.Levels) or result[n] then return nil end
            result[n] = {Kills=d:getInt('Kills'),OnlineSeconds=d:getInt('OnlineSeconds'),Points=d:getInt('Points'),Active=d:getInt('Active'),Free=d:getInt('FreeClaimed'),Vip=d:getInt('VipClaimed'),Donate=d:getInt('Donate'),DonateClaimed=d:getInt('DonateClaimed')}
        end
        for i=1,#C.Levels do if not result[i] then return nil end end
        return result
    end)
    pcall(function() d:clear() end)
    if not ok or not rows then logError(); return nil end
    return rows
end
sendPacket = function(player, sequence, kind, write)
    local n = 'BP-' .. player:getName()
    CreatePacket(n, C.Packet); SetDwordPacket(n, sequence); SetBytePacket(n, kind)
    write(n); SendPacket(n, player:getIndex()); ClearPacket(n)
end
local function sendString(n, value)
    value = tostring(value or ''):sub(1, 180)
    SetBytePacket(n, #value); SetCharPacketLength(n, value, #value)
end
local function rewardLabel(value)
    local amount,items=rewardData(value)
    if #items==0 then return tostring(amount),C.Currency.Name end
    local first=items[1]
    local detail
    if amount>0 then detail='+ '..amount..' '..C.Currency.Name
    elseif #items>1 then detail='+ '..(#items-1)..' item(ns)'
    elseif (first.Count or 1)>1 then detail='x'..first.Count
    else detail='ITEM' end
    return first.Name,detail
end
local function sendStatus(player, id, sequence, message)
    local rows = snapshot(id)
    if rows then
        sendPacket(player, sequence, 1, function(n)
            SetDwordPacket(n,C.Season); SetDwordPacket(n,rows[1].Points)
            SetBytePacket(n,rows[1].Active); SetBytePacket(n,eligibleVip(player) and 1 or 0); SetBytePacket(n,rows[1].Donate)
            SetBytePacket(n,#C.Levels); sendString(n,C.Currency.Name)
            SetDwordPacket(n,rows[1].Kills); SetDwordPacket(n,rows[1].OnlineSeconds)
            SetBytePacket(n,C.DonatePurchase.Enabled and 1 or 0); SetDwordPacket(n,C.DonatePurchase.Price); sendString(n,C.DonatePurchase.Name)
        end)
        for i,level in ipairs(C.Levels) do
            sendPacket(player, sequence, 2, function(n)
                SetBytePacket(n,i); SetDwordPacket(n,level.Points)
                for number=0,2 do
                    local title,detail=rewardLabel(rewardFor(level,number)); sendString(n,title); sendString(n,detail)
                end
                local kills,minutes=mission(level); SetDwordPacket(n,kills); SetDwordPacket(n,minutes)
                SetBytePacket(n,rows[i].Free); SetBytePacket(n,rows[i].Vip); SetBytePacket(n,rows[i].DonateClaimed)
            end)
            -- Em blocos pequenos para manter cada pacote dentro do limite do cliente.
            for number=0,2 do
                local track=number+1 -- o protocolo do cliente continua usando 1, 2 e 3.
                local _,items=rewardData(rewardFor(level,number))
                for start=1,#items,5 do
                    sendPacket(player,sequence,5,function(n)
                        SetBytePacket(n,i); SetBytePacket(n,track); SetBytePacket(n,#items)
                        SetBytePacket(n,start); SetBytePacket(n,math.min(5,#items-start+1))
                        for j=start,math.min(start+4,#items) do
                            local item=items[j]
                            SetDwordPacket(n,itemIndex(item))
                            for _,field in ipairs({'Level','Count','Skill','Luck','Option','Excellent','Ancient','JoH','SockBonus'}) do
                                SetBytePacket(n,item[field] or (field=='Count' and 1 or 0))
                            end
                            sendString(n,item.Name)
                        end
                    end)
                end
            end
        end
    end
    sendPacket(player, sequence, 3, function(n)
        sendString(n, rows and (message or '') or 'Banco indisponivel. Atualize novamente.')
    end)
end
local requestTimes = {}
function B.Protocol(index, number, name)
    if number ~= C.Packet or not integer(index,OBJECT_START_USER,MAX_OBJECT) then return end
    local player = User.new(index)
    if name ~= 'BPQ-' .. player:getName() then return end
    local action,sequence,level = GetBytePacket(name,-1),GetDwordPacket(name,-1),GetBytePacket(name,-1)
    ClearPacket(name)
    local id = account(player)
    if not id or not integer(sequence,1,MAX) or not integer(action,1,5) or not integer(level,0,100) then return true end
    local now = GetTick() % 4294967296
    if requestTimes[index] and (now-requestTimes[index])%4294967296 < 300 then return true end
    requestTimes[index] = now
    if not C.Enabled then
        sendPacket(player,sequence,3,function(n) sendString(n,'Sistema desativado.') end)
        return true
    end
    local message
    if action == 5 then message=buyDonate(id)
    elseif action >= 2 then
        message = claim(index,id,action == 2 and 'free' or action == 3 and 'vip' or 'don',level,player)
    end
    sendStatus(player,id,sequence,message)
    return true
end
-- Tempo confirmado em blocos de ate 60 segundos, nunca contado fora do jogo.
local sessions,retired={},{}
local function flush(session)
    local seconds=math.floor(session.Total/1000)
    if seconds<=session.Saved then return true end
    if not session.ID then
        local row=query(transact('DECLARE @result int; INSERT dbo.BattlePassOnlineSession(Season,AccountID) VALUES('..C.Season..','..quote(session.Account)..'); SET @result=CONVERT(int,SCOPE_IDENTITY());'),{'Result'})
        if not row or row.Result<1 then return false end
        session.ID=row.Result
    end
    local k=key(session.Account)
    -- SavedSeconds torna repeticoes depois de uma resposta perdida idempotentes.
    local sql='DECLARE @result int=0,@saved int,@delta int; SELECT @saved=SavedSeconds FROM dbo.BattlePassOnlineSession WITH (UPDLOCK,HOLDLOCK) WHERE SessionID='..session.ID..' AND '..k..'; IF @saved IS NULL RAISERROR(\'BattlePass: sessao invalida\',16,1); SET @delta=CASE WHEN @saved<'..seconds..' THEN '..seconds..'-@saved ELSE 0 END; IF '..active()..' BEGIN IF NOT EXISTS(SELECT 1 FROM dbo.BattlePassProgress WITH (UPDLOCK,HOLDLOCK) WHERE '..k..') INSERT dbo.BattlePassProgress(Season,AccountID,Points) VALUES('..C.Season..','..quote(session.Account)..',0); UPDATE dbo.BattlePassProgress SET OnlineSeconds=CASE WHEN CONVERT(bigint,OnlineSeconds)+@delta>'..MAX..' THEN '..MAX..' ELSE OnlineSeconds+@delta END WHERE '..k..'; END; UPDATE dbo.BattlePassOnlineSession SET SavedSeconds=CASE WHEN SavedSeconds<'..seconds..' THEN '..seconds..' ELSE SavedSeconds END WHERE SessionID='..session.ID..'; SET @result=1;'
    local row=query(transact(sql),{'Result'})
    if row and row.Result==1 then session.Saved=seconds; return true end
    return false
end
local function accrue(session,now)
    local delta=(now-session.Tick)%4294967296
    session.Tick=now
    -- Pausas longas do processo nao comprovam tempo online.
    if delta<=5000 then session.Total=math.min(MAX*1000,session.Total+delta) end
end
local function retire(session)
    if not flush(session) then retired[#retired+1]=session end
end
function B.Join(index)
    if not C.Enabled then return end
    local p=User.new(index); local id=account(p)
    if sessions[index] then B.Logout(index) end
    if id then sessions[index]={Account=id,Name=p:getName(),Tick=GetTick()%4294967296,Total=0,Saved=0} end
end
function B.Timer()
    if not C.Enabled then sessions={}; retired={}; return end
    local now=GetTick()%4294967296
    local seen={}
    for index,session in pairs(sessions) do
        local p=User.new(index)
        if account(p)~=session.Account or p:getName()~=session.Name then
            retire(session); sessions[index]=nil
        else
            if not seen[session.Account] then accrue(session,now) else session.Tick=now end
            seen[session.Account]=true
            if math.floor(session.Total/1000)-session.Saved>=60 then flush(session) end
        end
    end
    for i=#retired,1,-1 do if flush(retired[i]) then table.remove(retired,i) end end
end
function B.Logout(index)
    requestTimes[index]=nil
    local session=sessions[index]
    if session then
        local p=User.new(index)
        if account(p)==session.Account and p:getName()==session.Name then accrue(session,GetTick()%4294967296) end
        retire(session); sessions[index]=nil
    end
end
validate()
Commands.Register(C.Command, B.Command)
GameServerFunctions.MonsterDie(B.MonsterDie)
GameServerFunctions.GameServerProtocol(B.Protocol)
GameServerFunctions.PlayerLogout(B.Logout)
GameServerFunctions.EnterCharacter(B.Join)
Timer.Interval(1,B.Timer)
Timer.TimeOut(5,function()
    for i=OBJECT_START_USER,MAX_OBJECT do if User.new(i):getConnected()>=3 then B.Join(i) end end
end)
return B
