-- ============================================================
--  CONFIGURACAO DO PASSE DE BATALHA
--  Reinicie todos os GameServers depois de alterar este arquivo.
-- ============================================================
--
--  COMO CONFIGURAR UM NIVEL
--  Cada nivel tem 3 premios, sempre nesta ordem:
--      [0] = FREE   (todo mundo)
--      [1] = VIP    (precisa de VIP do jogo)
--      [2] = DONATE (precisa ter comprado o Donate)
--
--  Cada premio aceita os DOIS ao mesmo tempo (ou so um deles):
--      Cash  = quantidade de moeda (0 = nao da moeda)
--      Items = lista de itens (vazia {} = nao da item)
--  Todo premio precisa ter Cash maior que 0 OU pelo menos 1 item.
--
--  COMO ESCREVER UM ITEM  (so Category, Index e Name sao obrigatorios)
--      { Category=14, Index=13, Name='Jewel of Bless', Count=1 }
--
--  Todas as opcoes possiveis de um item (as que faltam valem 0):
--      Category  = grupo do item (0-15)         Index   = numero dentro do grupo (0-511)
--      Name      = nome mostrado no passe (ate 24 letras)
--      Count     = quantidade (1-10; cada unidade vira 1 item no NPC)
--      Level     = +nivel do item (0-15)        Skill   = 1 liga a skill
--      Luck      = 1 liga a sorte               Option  = opcao adicional (0-7)
--      Excellent = bits de excelente (0-63)     Ancient = ancient (0-255)
--      JoH       = Harmony (0-255)              SockBonus = bonus de socket (0-255)
--  Maximo de 10 itens por premio.
--
--      Time      = (opcional) duracao do item em segundos, so na entrega direta (0 = eterno)
--
--  Os itens vao direto para a mochila (ItemDelivery = 'inventory'). Se a mochila
--  encher no meio da entrega, o que sobrou vai para o NPC de resgate
--  (tabela NPC_RESCUE_ITENS), onde o jogador retira em ItemExpireDays dias.
-- ============================================================

BattlePassConfig = {
    Enabled = true,
    Command = '/passe',
    Packet = 221,
    Season = 1,
    MinVip = 1,                          -- nivel minimo de VIP do jogo para a trilha VIP
    StartUTC = '2026-11-01T00:00:00',
    EndUTC = '2027-02-01T00:00:00',      -- fim exclusivo, em UTC

    Monsters = { [4] = true },           -- so monstros da classe 4 contam pontos
    Currency = { Name = 'Cash', Table = 'MEMB_INFO', Column = 'cash', Key = 'memb___id' },
    DonatePurchase = {
        Enabled = true,
        Price = 30,
        Name = 'Reais',                  -- nome exibido; a compra desconta da coluna gold
        Table = 'MEMB_INFO',
        Column = 'gold',
        Key = 'memb___id',
    },
    -- ENTREGA DOS ITENS:
    --   'inventory' = direto na mochila ao resgatar (se nao houver espaco, o resgate
    --                 e recusado; se acabar o espaco no meio, a sobra vai ao NPC).
    --   'npc'       = tudo vai para o NPC de resgate.
    ItemDelivery = 'inventory',
    ItemExpireDays = 30,                 -- dias para retirar no NPC (so quando houver NPC)

    Levels = {

        -- ====================================================
        --  NIVEL 1
        -- ====================================================
        {
            Points = 100,                -- pontos necessarios (1 morte = 1 ponto)
            Kills = 0,                   -- mortes minimas exigidas (0 = sem exigencia extra)
            OnlineMinutes = 6,           -- minutos online exigidos (0 = sem exigencia)
            Premios = {
                [0] = { -- FREE
                    Cash = 0,
                    Items = {
                        { Category = 14, Index = 13, Name = 'Jewel of Bless', Count = 1 },
                    },
                },
                [1] = { -- VIP
                    Cash = 25,
                    Items = {
                        { Category = 14, Index = 14, Name = 'Jewel of Soul', Count = 1 },
                    },
                },
                [2] = { -- DONATE
                    Cash = 50,
                    Items = {
                        { Category = 14, Index = 16, Name = 'Jewel of Life', Count = 1 },
                    },
                },
            },
        },

        -- ====================================================
        --  NIVEL 2
        -- ====================================================
        {
            Points = 300,
            Premios = {
                [0] = { -- FREE
                    Cash = 20,
                    Items = {},
                },
                [1] = { -- VIP
                    Cash = 50,
                    Items = {},
                },
                [2] = { -- DONATE
                    Cash = 100,
                    Items = {},
                },
            },
        },

        -- ====================================================
        --  NIVEL 3
        -- ====================================================
        {
            Points = 600,
            Premios = {
                [0] = { -- FREE
                    Cash = 30,
                    Items = {},
                },
                [1] = { -- VIP
                    Cash = 75,
                    Items = {},
                },
                [2] = { -- DONATE
                    Cash = 150,
                    Items = {},
                },
            },
        },

        -- Para criar mais niveis, copie um bloco acima e aumente Points
        -- (os pontos precisam ser sempre maiores que os do nivel anterior).
        -- Limite: 100 niveis.
    },
}
