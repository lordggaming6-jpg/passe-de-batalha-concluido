-- Interface do passe. Premios, requisitos e autorizacao pertencem ao servidor.
-- Trilhas: 0 = FREE (gratis), 1 = VIP, 2 = DONATE. Cada uma pode dar Cash e/ou itens.
BattlePassUI = {}
local U = BattlePassUI
U.Config = {Enabled=true, Packet=221, Shortcut=66, -- B; ajuste caso exista conflito.
    ShowItemIcons=true} -- false = mostra so o nome do item (sem icone 3D)
local C = U.Config
local S = {Open=false, Sequence=0, Page=0, Rows={}, Message='', Missions=false}
local controls, incoming = {}, nil
local shortcutDown = false
local X,Y,W,H = 34,50,571,358 -- Y maior = janela mais baixa (proporcao do arte: 1198x750)
local BACKGROUND = 620122
local DIGIT0 = 620123 -- ate 620132: imagens dos numeros grandes (BattlePassNum0..9)
local imagesLoaded = false
local gold,white,muted,green,red = {238,196,104},{225,225,220},{150,148,143},{147,218,153},{230,120,110}
local TRACK_NAME = {[0]='FREE',[1]='VIP',[2]='DONATE'}
-- Pacote: trilha 0/1/2 do servidor vira 1/2/3 no protocolo de itens.
local native = {1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,21,33,34,35,36,39,57,63,65,72,73,74,75,77,78,79}
local function yes(v) return v == true or v == 1 end
local function blocked()
    if UICustomInterface and UICustomInterface ~= 0 then return true end
    for _,id in ipairs(native) do if CheckWindowOpen(id)==1 then return true end end
    if UIChatWindow and CheckWindowOpen(UIChatWindow)==1 then return true end
    if QuestSystem and QuestSystem.CheckOpen and yes(QuestSystem.CheckOpen()) then return true end
    if QuestSystemNpc and QuestSystemNpc.CheckOpen and yes(QuestSystemNpc.CheckOpen()) then return true end
    if Shop and Shop.IsOpen and yes(Shop.IsOpen()) then return true end
    if GuardiaoBrindes and GuardiaoBrindes.CheckOpen and yes(GuardiaoBrindes.CheckOpen()) then return true end
    if LogInAndWinVisible == 1 then return true end
    return false
end
function U.CheckOpen() return S.Open and 1 or 0 end
local function over(x,y,w,h) return MousePosX()>=x and MousePosX()<=x+w and MousePosY()>=y and MousePosY()<=y+h end
local function bar(x,y,w,h,c)
    EnableAlphaTest(); SetBlend(); glColor4f(unpack(c)); DrawBar(x,y,w,h); EndDrawBar()
    GLSwitchBlend(); GLSwitch(); glColor3f(1,1,1); DisableAlphaBlend()
end
local function text(x,y,s,w,color,align)
    EnableAlphaTest(); SetFontType(1); SetTextBg(0,0,0,0); SetTextColor(color[1],color[2],color[3],255)
    RenderText3(x,y,tostring(s),w,align or 1); DisableAlphaBlend()
end
local function frame(x,y,w,h,highlight)
    bar(x,y,w,h,highlight and {.72,.53,.20,1} or {.34,.28,.17,1})
    bar(x+1,y+1,w-2,h-2,{.035,.045,.06,.98})
end
local function button(x,y,w,h,label,enabled,action)
    local hover=enabled and over(x,y,w,h)
    frame(x,y,w,h,hover)
    bar(x+2,y+2,w-4,h-4,enabled and {.24,.17,.07,1} or {.10,.10,.11,1})
    text(x+2,y+(h-10)/2,label,w-4,enabled and gold or muted,3)
    if enabled then controls[#controls+1]={x=x,y=y,w=w,h=h,action=action} end
end
-- action: 1 atualizar | 2 resgatar FREE | 3 resgatar VIP | 4 resgatar DONATE | 5 comprar Donate
local function request(action,level)
    if not S.Open or S.Waiting or blocked() then return end
    S.Sequence=S.Sequence%2147483646+1
    S.Waiting=true; S.Sent=os.time(); S.Valid=false; S.Action=action; S.Confirm=nil
    S.Message=action==1 and 'Atualizando...' or action==5 and 'Comprando...' or 'Resgatando...'
    incoming={Rows={}}
    local n='BPQ-'..UserGetName(); CreatePacket(n,C.Packet)
    SetBytePacket(n,action); SetDwordPacket(n,S.Sequence); SetBytePacket(n,level or 0)
    SendPacket(n); ClearPacket(n)
end
function U.Close()
    if not S.Open then return end
    S.Open=false; S.Waiting=false; S.Valid=false; S.Confirm=nil; S.Sequence=S.Sequence%2147483646+1
    controls={}; incoming=nil; DisableClickClient(); SetUnlockInterfaces()
end
function U.LoadImages()
    if imagesLoaded then return end
    LoadImage('Custom\\Interface\\BattlePassFundo.tga',BACKGROUND)
    for d=0,9 do LoadImage('Custom\\Interface\\BattlePassNum'..d..'.tga',DIGIT0+d) end
    imagesLoaded = true
end
function U.Open()
    if not C.Enabled or blocked() then return end
    if not imagesLoaded then U.LoadImages() end
    S.Open=true; S.Name=UserGetName(); S.Page=0; S.Rows={}; S.Valid=false; S.Waiting=false; S.Missions=false; S.Confirm=nil
    S.Message='Carregando...'; controls={}; SetLockInterfaces(); DisableClickClient(); request(1)
end
local function readstr(n) return GetCharPacketLength(n,-1,GetBytePacket(n,-1)) end
function U.Protocol(number,n)
    if number~=C.Packet or n~='BP-'..UserGetName() then return end
    local sequence,kind=GetDwordPacket(n,-1),GetBytePacket(n,-1)
    -- Aviso do servidor ao digitar o comando do passe: abre a janela.
    if kind==4 then ClearPacket(n); if not S.Open then U.Open() end; return true end
    if not S.Open or not S.Waiting or sequence~=S.Sequence or S.Name~=UserGetName() then ClearPacket(n); return true end
    local v=incoming
    if kind==1 then
        v.Season=GetDwordPacket(n,-1); v.Points=GetDwordPacket(n,-1)
        v.Active=GetBytePacket(n,-1)==1; v.Vip=GetBytePacket(n,-1)==1; v.Donate=GetBytePacket(n,-1)==1
        v.Count=GetBytePacket(n,-1); v.Currency=readstr(n)
        v.Kills=GetDwordPacket(n,-1); v.OnlineSeconds=GetDwordPacket(n,-1)
        v.BuyEnabled=GetBytePacket(n,-1)==1; v.BuyPrice=GetDwordPacket(n,-1); v.BuyName=readstr(n)
        v.Started=true
    elseif kind==2 and v.Started then
        local i=GetBytePacket(n,-1)
        local row={Required=GetDwordPacket(n,-1),Titles={},Details={},Items={[0]={},[1]={},[2]={}},Total={},Claimed={}}
        for number=0,2 do row.Titles[number]=readstr(n); row.Details[number]=readstr(n) end
        row.Kills=GetDwordPacket(n,-1); row.Minutes=GetDwordPacket(n,-1)
        for number=0,2 do row.Claimed[number]=GetBytePacket(n,-1)==1 end
        if i>=1 and i<=v.Count and not v.Rows[i] then v.Rows[i]=row else v.Invalid=true end
    elseif kind==5 and v.Started then
        -- Itens do premio, em blocos de ate 5: nivel, trilha(1-3), total, inicio, quantidade.
        local i,track,total,start,count=GetBytePacket(n,-1),GetBytePacket(n,-1),GetBytePacket(n,-1),GetBytePacket(n,-1),GetBytePacket(n,-1)
        local row=v.Rows[i]; local number=track-1
        if not row or number<0 or number>2 or start~=#row.Items[number]+1 then v.Invalid=true
        else
            row.Total[number]=total
            for _=1,count do
                local item={Index=GetDwordPacket(n,-1)}
                item.Level=GetBytePacket(n,-1); item.Count=GetBytePacket(n,-1); item.Skill=GetBytePacket(n,-1)
                item.Luck=GetBytePacket(n,-1); item.Option=GetBytePacket(n,-1); item.Excellent=GetBytePacket(n,-1)
                item.Ancient=GetBytePacket(n,-1); item.JoH=GetBytePacket(n,-1); item.SockBonus=GetBytePacket(n,-1)
                item.Name=readstr(n)
                row.Items[number][#row.Items[number]+1]=item
            end
        end
    elseif kind==3 then
        local message=readstr(n); S.Waiting=false; S.LastUpdate=os.time()
        local complete=v.Started and not v.Invalid and v.Count>=1 and v.Count<=100
        if complete then
            for i=1,v.Count do
                local row=v.Rows[i]
                if not row then complete=false; break end
                for number=0,2 do if (row.Total[number] or 0)~=#row.Items[number] then complete=false end end
            end
        end
        if complete then
            S.Rows=v.Rows; S.Season=v.Season; S.Points=v.Points; S.Active=v.Active; S.Vip=v.Vip; S.Donate=v.Donate; S.Currency=v.Currency
            S.Kills=v.Kills; S.Online=v.OnlineSeconds; S.BuyEnabled=v.BuyEnabled; S.BuyPrice=v.BuyPrice; S.BuyName=v.BuyName
            S.Page=math.min(S.Page,math.floor((#S.Rows-1)/3)); S.Valid=true
            S.Message=message~='' and message or (S.Active and 'Passe o mouse em um premio para ver os itens.' or 'Temporada fora do periodo ativo.')
        else S.Valid=false; S.Message=message~='' and message or 'Resposta incompleta. Clique em atualizar.' end
        incoming=nil
    end
    ClearPacket(n); return true
end
function U.Update()
    if not S.Open then return end
    if not C.Enabled or S.Name~=UserGetName() or blocked() then U.Close(); return end
    if S.Confirm and os.time()-S.Confirm>=5 then S.Confirm=nil end
    if S.Waiting and os.time()-S.Sent>=8 then
        S.Waiting=false; S.Valid=false; incoming=nil; S.LastUpdate=os.time()
        S.Message='Sem resposta. Atualize antes de resgatar novamente.'
    end
end
-- Texto curto do item para o tooltip: nome, +nivel e opcoes.
local function itemLine(item)
    local t=(item.Count>1 and (item.Count..'x ') or '')..item.Name
    if item.Level>0 then t=t..' +'..item.Level end
    if item.Skill>0 then t=t..' +Skill' end
    if item.Luck>0 then t=t..' +Luck' end
    if item.Option>0 then t=t..' +Opt'..(item.Option*4) end
    if item.Excellent>0 then t=t..' +Exc' end
    if item.Ancient>0 then t=t..' +Anc' end
    if item.JoH>0 then t=t..' +Harmony' end
    if item.SockBonus>0 then t=t..' +Socket' end
    return t
end
local function missionDone(row)
    return (S.Kills or 0)>=row.Kills and (S.Online or 0)>=row.Minutes*60
end
local function tooltip()
    local t=S.Tip; S.Tip=nil
    if not t then return end
    local row,number=t.row,t.number
    local lines={{TRACK_NAME[number]..' - NIVEL '..t.level,gold}}
    local items=row.Items[number]
    if #items==0 then lines[#lines+1]={row.Titles[number]..' '..(S.Currency or ''),white}
    else
        for _,item in ipairs(items) do lines[#lines+1]={itemLine(item),white} end
        if row.Details[number]:sub(1,1)=='+' and row.Details[number]:find(S.Currency or '',1,true) then lines[#lines+1]={row.Details[number],gold} end
    end
    if not t.pointsOk then lines[#lines+1]={'Faltam pontos para este nivel.',red}
    elseif not t.missionOk then lines[#lines+1]={'Complete as missoes do nivel (botao MISSOES).',red}
    elseif number==1 and not S.Vip then lines[#lines+1]={'Requer VIP do jogo.',red}
    elseif number==2 and not S.Donate then lines[#lines+1]={'Requer o Donate.',red} end
    local w=60
    for _,l in ipairs(lines) do w=math.max(w,#l[1]*6+14) end
    local h=#lines*13+8
    local tx=math.min(MousePosX()+14,X+W-w-4); local ty=math.min(MousePosY()+14,Y+H-h-4)
    frame(tx,ty,w,h,true)
    for i,l in ipairs(lines) do text(tx+6,ty+5+(i-1)*13,l[1],w-10,l[2]) end
end
local function none(v) return (v or 0)==0 and 255 or v end -- 255 = "sem" para Ancient/JoH/Socket
-- "+ 25 Cash" -> "+25","Cash"; "ITEM" -> "ITEM","1 / n"; "x2" -> texto,"".
local function splitDetail(d,count)
    local a,c=(d or ''):match('^%+ (%d+) (.+)$')
    if a then return '+'..a,c end
    if d=='ITEM' then return 'ITEM','1 / '..tostring(count or 1) end
    if d and d:match('^x%d+$') then return 'ITEM',d end
    return d or '',''
end
-- ===== Layout novo (medidas do arte de referencia 1190x768, escaladas para W x H) =====
local K = W/1198 -- arte recortado: x 48..1246, y 8..758 (coordenadas da referencia)
local function sx(v) return X+(v-48)*K end
local function sy(v) return Y+(v-8)*K end
local function sw(v) return v*K end
local ITEM_SCALE = 0.55 -- tamanho do modelo 3D dentro do cartao (menor = item menor)
local PAGE = 3 -- niveis por pagina (3 colunas)
local COLS = {{306,240},{555,233},{798,233}} -- x,largura de cada coluna (NIVEL n)
local ROWS = {{333,97},{441,96},{548,97}}    -- y,altura de cada trilha (FREE/VIP/DONATE)
local function cellRect(slot,number)
    local c,r=COLS[slot],ROWS[number+1]
    return sx(c[1]),sy(r[1]),sw(c[2]),sw(r[2])
end
local function ctext(cx,cy,s,w,color) text(cx-w/2,cy-5,s,w,color,3) end
local function stext(cx,cy,s,w,color) ctext(cx+1,cy+1,s,w,{0,0,0}); ctext(cx,cy,s,w,color) end
local function outline(x,y,w,h,c)
    bar(x,y,w,1,c); bar(x,y+h-1,w,1,c); bar(x,y,1,h,c); bar(x+w-1,y,1,h,c)
end
local function drawLock(x,y)
    local g={.66,.66,.69,1}
    bar(x,y+4,9,7,g); bar(x+2,y,1.5,5,g); bar(x+5.5,y,1.5,5,g); bar(x+2,y,5.5,1.5,g)
    bar(x+4,y+6,1,3,{.10,.10,.12,1})
end
-- Area clicavel/botao desenhado no arte (coordenadas do arte de referencia).
local function hit(xo,yo,wo,ho,enabled,action)
    local x,y,w,h=sx(xo),sy(yo),sw(wo),sw(ho)
    if enabled then
        if over(x,y,w,h) then bar(x,y,w,h,{1,1,1,.12}) end
        controls[#controls+1]={x=x,y=y,w=w,h=h,action=action}
    else bar(x,y,w,h,{0,0,0,.55}) end
end
local function reward(slot,row,number,claimed,unlocked,level,pointsOk,missionOk)
    local x,y,w,h=cellRect(slot,number)
    local can=S.Valid and S.Active and not S.Waiting and unlocked and not claimed
    local items=row.Items[number]
    local hasIcon=#items>0 and C.ShowItemIcons
    local cx=x+w/2
    if can then
        bar(x+2,y+2,w-4,h-4,{.95,.70,.18,.07})
        outline(x,y,w,h,over(x,y,w,h) and {1,.85,.35,1} or {.85,.62,.18,1})
    end
    if #items>0 then
        local l1,l2=splitDetail(row.Details[number],#items)
        if hasIcon then
            -- Icone do item a esquerda (caixa escura), textos a direita.
            -- Cartao do item bem grande (ocupa a altura da celula), "1x" no canto e nivel embaixo.
            local bx,by,bw,bh=x+sw(8),y+sw(6),sw(84),sw(85)
            local it=items[1]
            bar(bx,by,bw,bh,{.015,.02,.03,1}); bar(bx,by,bw,sw(3),{.55,.42,.18,.9}); outline(bx,by,bw,bh,{.30,.26,.18,1})
            S.Icons[#S.Icons+1]={X=bx+1,Y=by+4,W=bw-2,H=bh-6,Item=it}
            if S.Valid and over(bx,by,bw,bh) then S.IconHover=it end
            text(bx+3,by+5,(it.Count or 1)..'x',sw(40),{175,170,160})
            if (it.Level or 0)>0 then text(bx+bw-17,by+bh-13,'+'..it.Level,sw(30),gold) end
            local tx=x+sw(92)+(w-sw(100))/2
            ctext(tx,y+sw(30),l1:sub(1,10),w-sw(100),white)
            if l2~='' then ctext(tx,y+sw(52),l2:sub(1,10),w-sw(100),white) end
        else
            ctext(cx,y+sw(27),(row.Titles[number] or ''):sub(1,16),w-4,white)
            ctext(cx,y+sw(48),(row.Details[number] or ''):sub(1,16),w-4,white)
        end
    else
        ctext(cx,y+sw(27),(row.Titles[number] or ''):sub(1,16),w-4,white)
        ctext(cx,y+sw(48),(S.Currency or ''):sub(1,16),w-4,white)
    end
    local yc=y+sw(80)
    if hasIcon then
        local gx=x+sw(92)+(w-sw(100))/2
        if claimed then ctext(gx,yc,'RESGATADO',w,green)
        elseif can then ctext(gx,yc,'RESGATAR',w,gold)
        else drawLock(gx-31,yc-6); ctext(gx+7,yc,'BLOQUEADO',w,muted) end
    else
        local gx=cx
        if claimed then ctext(gx,yc,'RESGATADO',w,green)
        elseif can then ctext(gx,yc,'RESGATAR',w,gold)
        else drawLock(gx-sw(56)-4,yc-6); ctext(gx+sw(14),yc,'BLOQUEADO',w,muted) end
    end
    if S.Valid and over(x,y,w,h) then S.Tip={row=row,number=number,level=level,pointsOk=pointsOk,missionOk=missionOk} end
    if can then controls[#controls+1]={x=x,y=y,w=w,h=h,action=function() request(number==2 and 4 or number==1 and 3 or 2,level) end} end
end
-- Modo MISSOES: cada coluna (nivel) mostra pontos / mortes / minutos online nas 3 linhas.
local function missionCell(slot,number,v)
    local x,y,w,h=cellRect(slot,number)
    local cx=x+w/2
    local label,cur,req,unit
    if number==0 then label,cur,req,unit='PONTOS',S.Points or 0,v.Required,''
    elseif number==1 then label,cur,req,unit='MORTES',S.Kills or 0,v.Kills,''
    else label,cur,req,unit='ONLINE',math.floor((S.Online or 0)/60),v.Minutes,' min' end
    ctext(cx,y+sw(27),label,w,gold)
    if number>0 and req==0 then
        ctext(cx,y+sw(48),'Sem exigencia',w,muted)
    else
        local ok=cur>=req
        ctext(cx,y+sw(48),math.min(cur,req)..' / '..req..unit,w,ok and green or white)
        ctext(cx,y+sw(80),ok and 'COMPLETO' or 'EM ANDAMENTO',w,ok and green or muted)
    end
end
-- Icones 3D desenhados depois do painel (mesma funcao nativa usada na quest).
local function drawIcons()
    for _,ic in ipairs(S.Icons) do
        local it=ic.Item
        DisableAlphaBlend()
        -- O motor desenha o modelo 3D proporcional ao tamanho do item (espada 1x4 passa da caixa);
        -- por isso o icone usa so uma parte da caixa, centralizada. Ajuste ITEM_SCALE se quiser.
        local sc=ITEM_SCALE; local iw,ih=ic.W*sc,ic.H*sc
        CreateItem(ic.X+(ic.W-iw)/2,ic.Y+(ic.H-ih)/2,iw,ih,it.Index,it.Level,it.Excellent,none(it.Ancient),1)
    end
    if S.IconHover then
        local it=S.IconHover; S.Tip=nil
        EnableAlphaTest(); glColor4f(1,1,1,1)
        -- ordem nativa: Op1(Skill), Op2(Luck), Life(Option), Exc, Ancient, JoH, SocketBonus, Sock1-5
        ShowDescriptionComplete(MousePosX()+20,MousePosY(),it.Index,it.Level,it.Skill,it.Luck,it.Option,it.Excellent,
            none(it.Ancient),it.JoH or 0,none(it.SockBonus),255,255,255,255,255)
        DisableAlphaBlend()
    end
end
function U.Render()
    U.Update(); controls={}; if not S.Open then return end
    S.Icons={}; S.IconHover=nil
    EnableAlphaTest(); glColor4f(1,1,1,1)
    RenderImage2(BACKGROUND,X,Y,W,H,0,0,1,1,1,1,1); DisableAlphaBlend()
    hit(1180,63,47,47,true,U.Close) -- botao X do arte
    -- Cabecalho: temporada, nivel e barra de EXP.
    stext(sx(546),sy(136),tostring(S.Season or '-'),sw(34),{235,235,240})
    local level=0
    for i,v in ipairs(S.Rows) do if (S.Points or 0)>=v.Required then level=i end end
    -- Numero do nivel grande (imagens BattlePassNum0..9, centralizado no escudo).
    do
        local str=tostring(level); local dw,dh,step=sw(48),sw(96),sw(40)
        local x0=sx(190)-(step*(#str-1)+dw)/2; local y0=sy(197)-dh/2
        EnableAlphaTest(); glColor4f(1,1,1,1)
        for i=1,#str do
            local d=tonumber(str:sub(i,i))
            RenderImage2(DIGIT0+d,x0+(i-1)*step,y0,dw,dh,0,0,1,1,1,1,1)
        end
        DisableAlphaBlend()
    end
    local nextLevel=S.Rows[level+1]
    local target=nextLevel and nextLevel.Required or (S.Rows[#S.Rows] and S.Rows[#S.Rows].Required or 0)
    local previous=level>0 and S.Rows[level].Required or 0
    local ratio=target>previous and math.max(0,math.min(1,((S.Points or 0)-previous)/(target-previous))) or (target>0 and 1 or 0)
    local fx,fy,fw,fh=sx(331),sy(201),sw(418)*ratio,sw(20)
    if fw>0.5 then
        bar(fx,fy,fw,fh,{.86,.58,.06,1}); bar(fx,fy,fw,fh*.45,{1,.80,.25,1}); bar(fx,fy+fh-1.2,fw,1.2,{.55,.34,.03,1})
    end
    text(sx(330),sy(247)-5,tostring(S.Points or 0)..' / '..tostring(target)..' pontos',sw(230),white)
    -- Caixa de status: VIP do jogo e Donate (com botao de compra).
    ctext(sx(1034),sy(227),S.Vip and 'VIP DO JOGO ATIVO' or 'NECESSITA VIP DO JOGO',sw(330),S.Vip and green or white)
    local bx,by,bw,bh=sx(867),sy(242),sw(334),sw(40)
    if S.Valid and S.Active and S.BuyEnabled and not S.Donate then
        local label=S.Confirm and ('CONFIRMAR? '..S.BuyPrice..' '..(S.BuyName or '')) or ('COMPRAR DONATE '..S.BuyPrice..' '..(S.BuyName or ''))
        stext(sx(1034),sy(262),label:sub(1,30),sw(330),{255,250,235})
        hit(867,242,334,40,not S.Waiting,function()
            if S.Confirm then request(5,0) else S.Confirm=os.time() end
        end)
    else
        bar(bx,by,bw,bh,{.03,.04,.06,.97})
        if S.Donate then ctext(sx(1034),sy(262),'DONATE ATIVO',sw(330),green)
        else ctext(sx(1034),sy(262),'DONATE INATIVO',sw(330),muted) end
    end
    -- Grade 3 niveis x 3 trilhas.
    local first=S.Page*PAGE+1
    for slot=1,PAGE do
        local i=first+slot-1; local v=S.Rows[i]
        if v then
            local c=COLS[slot]
            ctext(sx(c[1]+c[2]/2),sy(315),'NIVEL '..i,sw(c[2]),gold)
            if S.Missions then
                for number=0,2 do missionCell(slot,number,v) end
            else
                local pointsOk=(S.Points or 0)>=v.Required
                local missionOk=(S.Kills or 0)>=v.Kills and (S.Online or 0)>=v.Minutes*60
                local ok=pointsOk and missionOk
                reward(slot,v,0,v.Claimed[0],ok,i,pointsOk,missionOk)
                reward(slot,v,1,v.Claimed[1],ok and S.Vip,i,pointsOk,missionOk)
                reward(slot,v,2,v.Claimed[2],ok and S.Donate,i,pointsOk,missionOk)
            end
        end
    end
    -- Rodape: paginacao, missoes, atualizar e mensagem.
    local pages=math.max(1,math.ceil(#S.Rows/PAGE))
    hit(283,661,55,39,S.Page>0 and not S.Waiting,function() S.Page=S.Page-1 end)
    ctext(sx(417),sy(682),math.min(S.Page+1,pages)..' / '..pages,sw(120),white)
    hit(494,661,59,39,first+PAGE-1<#S.Rows and not S.Waiting,function() S.Page=S.Page+1 end)
    hit(677,655,257,51,S.Valid,function() S.Missions=not S.Missions end)
    stext(sx(805),sy(681),S.Missions and 'PREMIOS' or 'MISSOES',sw(240),white)
    hit(954,655,252,51,not S.Waiting,function() request(1) end)
    text(sx(178),sy(722)-5,(S.Message or ''):sub(1,90),sw(1000),white)
    drawIcons()
    tooltip()
end
function U.Mouse()
    if not S.Open then return end
    if blocked() then U.Close(); return end
    SetLockInterfaces()
    local click=CheckClickClient()==1; DisableClickClient()
    if not click then return end
    for _,v in ipairs(controls) do
        if over(v.x,v.y,v.w,v.h) then v.action(); controls={}; return end
    end
end
function U.Keys()
    local pressed=CheckPressedKey(C.Shortcut)==1
    local held=pressed or (CheckRepeatKey and CheckRepeatKey(C.Shortcut)==1)
    local toggle=pressed and not shortcutDown; shortcutDown=held
    if not C.Enabled then if S.Open then U.Close() end; return end
    if blocked() then if S.Open then U.Close() end; return end
    if S.Open and CheckPressedKey(Keys.Escape)==1 then U.Close(); return end
    if toggle then DisableClickClient(); if S.Open then U.Close() else U.Open() end end
end
InterfaceController.LoadImages(U.LoadImages)
InterfaceController.ClientProtocol(U.Protocol)
InterfaceController.BeforeMainProc(U.Render)
InterfaceController.UpdateMouse(U.Mouse)
InterfaceController.UpdateKey(U.Keys)
InterfaceController.UpdateProc(U.Update)
return U
